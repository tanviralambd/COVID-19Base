#/bin/sh

echo "hello"


grep -iwn  Ebola Diseases.owl
grep -iwn  MARS Diseases.owl
grep -iwn  SARS Diseases.owl
grep -iwn  COVID Diseases.owl
grep -iwn  sars-cov Diseases.owl


# DRUGS with adverse side effect
grep -in   hydroxychloroquine  drugbank\ vocabulary.csv
grep -in   interferon   drugbank\ vocabulary.csv


# DRUGS effective for EBOLA
grep -in   remdisivir   drugbank\ vocabulary.csv
grep -in   Ribavirin   drugbank\ vocabulary.csv



# DRUGS effective for hepatitis C virus (HCV), 
grep -in   miravirsen   drugbank\ vocabulary.csv
grep -in   Sofosbuvir   drugbank\ vocabulary.csv

#HUman cytomegalo virus (HCMV)  
# MISSING
grep -in   formivirsen   drugbank\ vocabulary.csv



# HIV 
#  highly active antiviral therapy  (HAART)
HIV therapy was the development of highly active antiviral therapy (HAART), which is based on simultaneous administration of combinations of HIV antivirals.  


# ALL DISEASE NAMES

grep -iwn rdfs:label  Diseases.owl  > DiseaseName.txt

